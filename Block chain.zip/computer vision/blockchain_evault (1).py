Vision Enhanced Blockchain Based eVault 

# Install dependencies
!pip install pytesseract opencv-python pillow scikit-learn joblib PyPDF2 pdf2image
!sudo apt install tesseract-ocr poppler-utils

# Import required libraries
from google.colab import files
import os
import zipfile

# eVault - Blockchain Document Management System
import os
import shutil
import hashlib
import json

import sqlite3
from datetime import datetime
# import face_recognition
import cv2
from PIL import Image
import pytesseract
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import make_pipeline

# CONFIGURATION
class Config:
    # To use current working directory in Colab
    BASE_DIR = os.getcwd()

    DOCUMENTS_DIR = os.path.join(BASE_DIR, "data", "documents")
    DB_PATH = os.path.join(BASE_DIR, "db", "evault.db")
    MODEL_PATH = os.path.join(BASE_DIR, "models", "classifier.pkl")
    CHAIN_FILE = os.path.join(BASE_DIR, "evault_chain.json")
    LOG_DIR = os.path.join(BASE_DIR, "logs")
    LOG_FILE = os.path.join(LOG_DIR, "activity.log")
    UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
    VAULT_DIR = os.path.join(BASE_DIR, "vault")
    ALLOWED_EXTENSIONS = ['pdf', 'png', 'jpg', 'jpeg', 'txt']

    @staticmethod
    def init_directories():
        """Create all required directories"""
        os.makedirs(Config.DOCUMENTS_DIR, exist_ok=True)
        os.makedirs(os.path.dirname(Config.DB_PATH), exist_ok=True)
        os.makedirs(os.path.dirname(Config.MODEL_PATH), exist_ok=True)
        os.makedirs(Config.LOG_DIR, exist_ok=True)
        os.makedirs(Config.UPLOAD_DIR, exist_ok=True)
        os.makedirs(Config.VAULT_DIR, exist_ok=True)

# CORE FUNCTIONALITY
class DocumentHandler:
    @staticmethod
    def upload_document(file_path):
        """Handle document uploads to the uploads directory"""
        if not os.path.exists(file_path):
            print("❌ File does not exist.")
            return None

        os.makedirs(Config.UPLOAD_DIR, exist_ok=True)
        destination_path = os.path.join(Config.UPLOAD_DIR, os.path.basename(file_path))
        shutil.copy2(file_path, destination_path)
        print(f"✅ Document uploaded successfully to {destination_path}")
        return destination_path

class VisionModule:
    def __init__(self):
        """Initialize with Colab-specific configurations"""
        self._init_tesseract()

        # Handle face detection fallbacks
        self.face_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
        )
        self._face_detection_methods = [
            self._try_gpu_face_detection,
            self._try_hog_face_detection,
            self._try_opencv_face_detection
        ]

    def _init_tesseract(self):
        """Configure Tesseract paths for different environments"""
        try:
            pytesseract.pytesseract.tesseract_cmd = r"/usr/bin/tesseract"
        except:
            try: # In case, Running locally
                pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
            except:
                pass  # system PATH as final fallback

    # FACE DETECTION
    def detect_faces(self, image_path):
        for method in self._face_detection_methods:
            try:
                faces = method(image_path)
                if faces is not None:
                    return faces
            except Exception as e:
                print(f"⚠️ {method.__name__} failed: {str(e)}")
                continue

        print("❌ All face detection methods failed")
        return []

    def _try_gpu_face_detection(self, image_path):
        """GPU-accelerated face detection"""
        image = face_recognition.load_image_file(image_path)
        return face_recognition.face_locations(image)

    def _try_hog_face_detection(self, image_path):
        """CPU-based HOG model face detection"""
        image = face_recognition.load_image_file(image_path)
        return face_recognition.face_locations(image, model="hog")

    def _try_opencv_face_detection(self, image_path):
        """OpenCV Haar Cascade fallback"""
        img = cv2.imread(image_path)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = self.face_cascade.detectMultiScale(gray, 1.1, 5)
        return [(y, x+w, y+h, x) for (x, y, w, h) in faces]  # Convert format

    # TEXT EXTRACTION
    def extract_text(self, file_path):
        """
        Text extraction for all supported file types:
        - Images (JPG/PNG)
        - PDFs (text-based and scanned)
        - Text files
        """
        file_ext = os.path.splitext(file_path)[1].lower()

        if file_ext in ('.png', '.jpg', '.jpeg'):
            return self.extract_text_from_image(file_path)
        elif file_ext == '.pdf':
            return self.extract_pdf_text(file_path)
        elif file_ext == '.txt':
            with open(file_path, 'r') as f:
                return f.read()
        else:
            raise ValueError(f"Unsupported file type: {file_ext}")

    def extract_text_from_image(self, image_path):
        """OCR text extraction from images"""
        try:
            img = Image.open(image_path)
            img = img.convert("RGB")
            text = pytesseract.image_to_string(img)
            return text.strip()
        except Exception as e:
            print(f"❌ OCR failed: {str(e)}")
            return ""

    def extract_pdf_text(self, pdf_path):
        """Handle both text-based and scanned PDFs"""
        try:
            text = self._extract_pdf_text_direct(pdf_path)
            if text.strip():
                return text

            # At end using OCR for scanned PDFs
            return self._extract_pdf_text_ocr(pdf_path)
        except Exception as e:
            print(f"❌ PDF processing failed: {str(e)}")
            return ""

    def _extract_pdf_text_direct(self, pdf_path):
        """Extract text from text-based PDFs"""
        from PyPDF2 import PdfReader
        with open(pdf_path, 'rb') as f:
            reader = PdfReader(f)
            return "\n".join([page.extract_text() for page in reader.pages])

    def _extract_pdf_text_ocr(self, pdf_path):
        """OCR for scanned PDFs"""
        from pdf2image import convert_from_path
        images = convert_from_path(pdf_path)
        return "\n".join([self.extract_text_from_image(img) for img in images])

class MLClassifier:
    def __init__(self):
        self.classifier = self._load_or_create_classifier()

    def _load_or_create_classifier(self):
        """Load existing classifier or create a new one"""
        try:
            if os.path.exists(Config.MODEL_PATH):
                return joblib.load(Config.MODEL_PATH)
            else:
                return make_pipeline(TfidfVectorizer(), MultinomialNB())
        except:
            return make_pipeline(TfidfVectorizer(), MultinomialNB())

    def classify_document(self, text):
        """Classifying document text into categories"""
        try:
            return self.classifier.predict([text])[0]
        except:
            return "Uncategorized"

    def train_classifier(self, text_samples, labels):
        """Train the classifier with new data"""
        self.classifier = make_pipeline(TfidfVectorizer(), MultinomialNB())
        self.classifier.fit(text_samples, labels)
        joblib.dump(self.classifier, Config.MODEL_PATH)
        print("✅ Classifier retrained and saved.")

class Blockchain:
    def __init__(self):
        self.chain = self._load_or_create_chain()

    def _load_or_create_chain(self):
        """Initialize or load existing blockchain"""
        if os.path.exists(Config.CHAIN_FILE):
            with open(Config.CHAIN_FILE, "r") as f:
                return json.load(f)
        else:
            # Genesis block
            genesis_block = [{
                "index": 0,
                "timestamp": str(datetime.now()),
                "data_hash": "GENESIS",
                "previous_hash": "0",
                "current_hash": self._calculate_hash(0, str(datetime.now()), "GENESIS", "0")
            }]
            self._save_chain(genesis_block)
            return genesis_block

    def _calculate_hash(self, index, timestamp, data_hash, previous_hash):
        """Calculate SHA-256 hash of block data"""
        block_string = f"{index}{timestamp}{data_hash}{previous_hash}"
        return hashlib.sha256(block_string.encode()).hexdigest()

    def _save_chain(self, chain):
        """Save blockchain to file"""
        with open(Config.CHAIN_FILE, "w") as f:
            json.dump(chain, f, indent=4)

    def add_document(self, document_text):
        """Add document to blockchain"""
        data_hash = hashlib.sha256(document_text.encode()).hexdigest()
        previous_block = self.chain[-1]

        new_block = {
            "index": len(self.chain),
            "timestamp": str(datetime.now()),
            "data_hash": data_hash,
            "previous_hash": previous_block["current_hash"],
        }
        new_block["current_hash"] = self._calculate_hash(
            new_block["index"],
            new_block["timestamp"],
            new_block["data_hash"],
            new_block["previous_hash"]
        )

        self.chain.append(new_block)
        self._save_chain(self.chain)
        return data_hash

    def verify_document(self, document_text):
        """Verify document integrity against blockchain"""
        target_hash = hashlib.sha256(document_text.encode()).hexdigest()
        for block in self.chain[1:]:  # Skip genesis block
            if block["data_hash"] == target_hash:
                return True
        return False

class StorageManager:
    def __init__(self):
        self._init_db()
        self.blockchain = Blockchain()

    def _init_db(self):
        """Initialize database and storage directories"""
        os.makedirs(Config.VAULT_DIR, exist_ok=True)
        conn = sqlite3.connect(Config.DB_PATH)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS documents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                filename TEXT,
                category TEXT,
                tags TEXT,
                hash TEXT,
                face_detected INTEGER DEFAULT 0,
                extracted_text TEXT,
                storage_path TEXT,
                upload_date TEXT
            )
        ''')
        conn.commit()
        conn.close()

    def store_document(self, source_path, metadata):
        """Store document in vault with metadata"""
        # Create organized storage path
        date_folder = datetime.now().strftime("%Y-%m-%d")
        storage_dir = os.path.join(Config.VAULT_DIR, metadata['category'], date_folder)
        os.makedirs(storage_dir, exist_ok=True)

        # Copy file to vault
        dest_path = os.path.join(storage_dir, metadata['filename'])
        shutil.copy2(source_path, dest_path)

        # Add to database
        conn = sqlite3.connect(Config.DB_PATH)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO documents (
                filename, category, tags, hash,
                face_detected, extracted_text, storage_path, upload_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            metadata['filename'],
            metadata['category'],
            metadata['tags'],
            metadata['hash'],
            metadata.get('face_detected', 0),
            metadata.get('extracted_text', ''),
            dest_path,
            str(datetime.now())
        ))
        conn.commit()
        conn.close()
        return dest_path

class DocumentRetriever:
    def __init__(self):
        self.db_path = Config.DB_PATH

    def search_by_tag(self, tag):
        """Search documents by tag"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM documents WHERE tags LIKE ?", (f"%{tag}%",))
        results = cursor.fetchall()
        conn.close()
        return results

    def search_by_filename(self, filename):
        """Search documents by filename"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM documents WHERE filename = ?", (filename,))
        result = cursor.fetchone()
        conn.close()
        return result

    def retrieve_document(self, doc_id=None, filename=None, tag=None):
        """Retrieve document by ID, filename, or tag"""
        if doc_id:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM documents WHERE id = ?", (doc_id,))
            result = cursor.fetchone()
            conn.close()
            return result

        if filename:
            return self.search_by_filename(filename)

        if tag:
            return self.search_by_tag(tag)

        return None

    def verify_document_integrity(self, file_path, stored_hash):
        """Verify document hasn't been tampered with"""
        with open(file_path, "rb") as f:
            content = f.read()
            current_hash = hashlib.sha256(content).hexdigest()
            return current_hash == stored_hash

class Logger:
    @staticmethod
    def log_event(event: str):
        """Log system events"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(Config.LOG_FILE, "a") as log:
            log.write(f"[{timestamp}] {event}\n")

# MAIN APPLICATION
class eVault:
    def __init__(self):
        Config.init_directories()
        self.vision = VisionModule()
        self.classifier = MLClassifier()
        self.storage = StorageManager()
        self.retriever = DocumentRetriever()
        self.logger = Logger
        self._setup_default_classifier()

    def _setup_default_classifier(self):
        """Setting up default classifier in case no model exists"""
        if not os.path.exists(Config.MODEL_PATH):
            sample_texts = [
                "Name: John Doe\nDOB: 1990\nID: ABC123",
                "Patient: Alice\nDiagnosis: Fever\nPrescription: XYZ",
                "Certificate of Completion\nCourse: AI & ML",
                "Invoice #12345\nAmount: $500\nDue Date: 2025-04-20"
            ]
            labels = ["ID Card", "Medical Record", "Certificate", "Invoice"]
            self.classifier.train_classifier(sample_texts, labels)

    def process_document(self, file_path):
        """Process uploaded document through the entire pipeline"""
        # Upload document
        uploaded_path = DocumentHandler.upload_document(file_path)
        if not uploaded_path:
            return None

        metadata = {
            "filename": os.path.basename(uploaded_path),
            "face_detected": 0
        }

        # Process image if it's an image file
        if uploaded_path.lower().endswith((".png", ".jpg", ".jpeg")):
            # Face detection
            faces = self.vision.detect_faces(uploaded_path)
            if faces:
                metadata["face_detected"] = len(faces)
                print(f"🧍 Detected {len(faces)} face(s) in the document")

            # Text extraction
            text = self.vision.extract_text_from_image(uploaded_path)
            if text:
                metadata["extracted_text"] = text
            else:
                print("⚠️ No text extracted from image")

        # For non-image files, read text directly
        elif uploaded_path.lower().endswith(".txt"):
            with open(uploaded_path, "r") as f:
                text = f.read()
                metadata["extracted_text"] = text

        # Classify document
        if "extracted_text" in metadata:
            category = self.classifier.classify_document(metadata["extracted_text"])
            print(f"🏷️ Suggested category: {category}")
            metadata["category"] = category
        else:
            metadata["category"] = "Uncategorized"

        # Get tags from user
        tags = input("Enter tags for this document (comma-separated): ").strip()
        metadata["tags"] = tags

        # Add to blockchain
        if "extracted_text" in metadata:
            metadata["hash"] = self.storage.blockchain.add_document(metadata["extracted_text"])
        else:
            with open(uploaded_path, "rb") as f:
                content = f.read()
                metadata["hash"] = hashlib.sha256(content).hexdigest()

        # Store document
        storage_path = self.storage.store_document(uploaded_path, metadata)
        print(f"✅ Document stored at: {storage_path}")
        self.logger.log_event(f"Document stored: {metadata['filename']}")
        return storage_path



    def retrieve_document_interactive(self):
        """Interactive document retrieval"""
        print("\n🔍 Search Options:")
        print("1. Search by tag")
        print("2. Search by filename")
        choice = input("Choose search method (1-2): ").strip()

        if choice == "1":
            tag = input("Enter tag to search: ").strip()
            results = self.retriever.search_by_tag(tag)
            if not results:
                print("❌ No documents found with that tag")
                return

            print("\n📄 Matching Documents:")
            for i, doc in enumerate(results, 1):
                print(f"{i}. {doc[1]} (Category: {doc[2]}, Tags: {doc[3]})")

            selection = input("Enter document number to view (or 0 to cancel): ").strip()
            try:
                selection = int(selection)
                if selection == 0:
                    return
                if 1 <= selection <= len(results):
                    self._display_document_details(results[selection-1])
            except ValueError:
                print("❌ Invalid selection")

        elif choice == "2":
            filename = input("Enter filename to search: ").strip()
            result = self.retriever.search_by_filename(filename)
            if result:
                self._display_document_details(result)
            else:
                print("❌ Document not found")

    def _display_document_details(self, document):
        """Display document details and verify integrity"""
        doc_id, filename, category, tags, doc_hash, face_detected, extracted_text, storage_path, upload_date = document

        print("\n📄 Document Details:")
        print(f"Filename: {filename}")
        print(f"Category: {category}")
        print(f"Tags: {tags}")
        print(f"Upload Date: {upload_date}")
        if face_detected:
            print(f"👤 Faces Detected: {face_detected}")

        # Verify integrity
        if os.path.exists(storage_path):
            is_valid = self.retriever.verify_document_integrity(storage_path, doc_hash)
            status = "✅ Verified" if is_valid else "❌ Tampered"
            print(f"Document Integrity: {status}")

            if extracted_text:
                print("\n📝 Extracted Text Preview:")
                print(extracted_text[:200] + ("..." if len(extracted_text) > 200 else ""))

            print(f"\nStorage Path: {storage_path}")
        else:
            print("❌ File not found in storage")

    def train_classifier_interactive(self):
        """Interactive classifier training"""
        print("\n🧠 Classifier Training")
        print("Enter sample documents and their categories")
        print("Enter 'done' when finished")

        samples = []
        labels = []

        while True:
            text = input("\nEnter sample document text (or 'done' to finish): ").strip()
            if text.lower() == 'done':
                break
            label = input("Enter category for this document: ").strip()
            samples.append(text)
            labels.append(label)

        if samples and labels:
            self.classifier.train_classifier(samples, labels)
            print("✅ Classifier training complete")
        else:
            print("❌ No samples provided")

    def run(self):
      """Main application loop with improved Colab uploads"""
      print("\n🔐 Welcome to eVault - Blockchain Document Management System")

      while True:
          print("\nMain Menu:")
          print("1. Upload & Process Document")
          print("2. Retrieve Documents")
          print("3. Train Classifier")
          print("4. View Blockchain")
          print("5. Exit")

          choice = input("Choose an option (1-5): ").strip()

          if choice == "1":
              self.upload_menu()  # NEW: Use the enhanced upload interface

          elif choice == "2":
              self.retrieve_document_interactive()

          elif choice == "3":
              self.train_classifier_interactive()

          elif choice == "4":
              self._display_blockchain()

          elif choice == "5":
              print("👋 Exiting eVault. Goodbye!")
              break

          else:
              print("❌ Invalid option")




    def upload_menu(self):
      """Enhanced Colab-friendly upload interface"""
      print("\n📁 Upload Options:")
      print("1. Upload single file")
      print("2. Upload zip archive (for datasets)")
      print("3. Enter Google Drive path")
      choice = input("Choose (1-3): ").strip()

      if choice == "1":
          from google.colab import files
          uploaded = files.upload()
          if not uploaded:
              print("❌ No files uploaded!")
              return None
          file_path = next(iter(uploaded))
          return self.process_document(file_path)

      elif choice == "2":
          # Dataset processing
          from google.colab import files
          import zipfile
          uploaded = files.upload()
          if not uploaded:
              print("❌ No zip file uploaded!")
              return None

          zip_path = next(iter(uploaded))
          with zipfile.ZipFile(zip_path, 'r') as zip_ref:
              zip_ref.extractall("temp_dataset")
              print(f"✅ Extracted {len(zip_ref.namelist())} files")

          # Process all files
          for root, _, files in os.walk("temp_dataset"):
              for file in files:
                  if file.lower().endswith(('.png', '.jpg', '.jpeg', '.pdf', '.txt')):
                      self.process_document(os.path.join(root, file))
          return "Dataset processed"

      elif choice == "3":
          drive_path = input("Enter Google Drive path (e.g. /content/drive/MyDrive/files/doc.jpg): ").strip()
          if os.path.exists(drive_path):
              return self.process_document(drive_path)
          else:
              print("❌ Path not found!")
      else:
          print("❌ Invalid choice")



    def _display_blockchain(self):
        """Display blockchain information"""
        print("\n⛓️ Blockchain Information")
        print(f"Chain length: {len(self.storage.blockchain.chain)} blocks")

        if input("View details? (y/n): ").lower() == 'y':
            for block in self.storage.blockchain.chain:
                print(f"\nBlock #{block['index']}")
                print(f"Timestamp: {block['timestamp']}")
                print(f"Data Hash: {block['data_hash'][:20]}...")
                print(f"Previous Hash: {block['previous_hash'][:20]}...")
                print(f"Current Hash: {block['current_hash'][:20]}...")

# ======================== RUN APPLICATION ========================
if __name__ == "__main__":
    app = eVault()
    app.run()